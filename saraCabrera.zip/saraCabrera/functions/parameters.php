<?php

    // Act 1
    $values = [
        "Juan" => [
            "DSW" => 5,
            "DPL" => 2,
            "DOR" => 7
        ],

        "María" => [
            "DSW" => 4,
            "DPL" => 4,
            "DOR" => 8
        ],

        "Álvaro" => [
            "DSW" => 10,
            "DPL" => 9,
            "DOR" => 9
        ]
    ];

?>