<?php
    function createTitle($title){
        print <<<END
            <h1 class="text-center w-100">$title</h1>
        END;
    }
?>