<?php
    return [
        "db" => [
            "host" => "localhost",
            "user" => "sara",
            "pass" => "12345",
            "name" => "school",
            "options" => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]
        ]
    ];
?>