<?php include "parts/header.php" ?>
<div class="container mt-3">
    <div class="row">
        <div class="col-md-12">
            <h1>Actividad CRUD</h1>

            <!-- Aquí van los enlaces a las implementaciones que se irán realizando -->
            <a href="create.php" class="btn btn-primary mt-4">Crear alumno/a</a>
            <a href="showusers.php" class="btn btn-primary mt-4">Mostrar alumnos</a>
        </div>
    </div>    
</div>
<?php include "parts/footer.php" ?>